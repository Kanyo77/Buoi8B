$(function() {  
    var date = [  
      {
        
"value":"Quat ban ",
"label":"Quat ban - 178.000",
"tenSp":"Quat ban ",
"DG":178.000,
"DVT":"Cái",
"Loại":"Gia dụng",
      } ,{
        "value":"May lanh ",
        "label":"May lanh - 3.200.000",
        "tenSp":"May lanhn ",
        "DG":3200.000,
        "DVT":"Cái",
        "Loại":"Gia dụng",
              } ,{
      }
    ];  
    $( "#txtsanpham" ).autocomplete({  
      source: Flowers 
    });  
  });  